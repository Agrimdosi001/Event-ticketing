# Campus Event Ticketing System

A multi-page event ticketing and check-in system. Students register for an event and receive an email with a cryptographically signed QR ticket. Organizers scan the QR code in a dedicated portal to check attendees in.

## Features

- **Registration portal**: browse events, see spots left, register. The server rejects registrations once an event reaches capacity (checked inside a database transaction, so simultaneous requests cannot oversell).
- **Transactional email**: an HTML email with an embedded QR code, sent through any SMTP provider (Brevo, SendGrid, Resend SMTP, Gmail, etc.) using Nodemailer.
- **Signed tickets**: each QR holds `ticketId.signature`, where the signature is an HMAC-SHA256 of the ticket ID using a server-side secret. Tickets cannot be forged without the secret.
- **Organizer scan portal**: webcam QR scanner with a manual token fallback, protected by an organizer key.
- **Anti-duplication**: the first valid scan sets the ticket to `CHECKED-IN`. Later scans return `ALREADY USED` with the original timestamp. Fake or malformed codes return `INVALID TICKET`.

## Tech stack

Node.js 18+, Express, SQLite (better-sqlite3), Nodemailer, qrcode, html5-qrcode.

## Project structure

```
server.js      Express app, API routes
db.js          SQLite schema and sample events
tokens.js      Ticket signing and verification (HMAC-SHA256)
mailer.js      Email template and sending
public/        Frontend pages: index, register, success, organizer
```

## Environment variables

Copy `.env.example` to `.env` and fill in the values. Never commit `.env`.

| Variable | Required | Description |
|---|---|---|
| `PORT` | No | Server port. Default `3000`. |
| `TICKET_SECRET` | Yes | Long random string used to sign tickets. Generate one with `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"`. Changing it invalidates all issued tickets. |
| `ORGANIZER_KEY` | Yes | Password entered on the organizer page. |
| `SMTP_HOST` | For real email | SMTP server host from your provider (Brevo: `smtp-relay.brevo.com`). |
| `SMTP_PORT` | For real email | Usually `587` (STARTTLS) or `465` (SSL). |
| `SMTP_USER` | For real email | SMTP login from your provider. |
| `SMTP_PASS` | For real email | SMTP key or password from your provider. For Gmail, use an App Password (needs 2-step verification). |
| `MAIL_FROM` | For real email | Sender, e.g. `"Campus Events <you@example.com>"`. Must be a sender your provider has verified. |
| `DEV_MODE` | No | `true` skips sending email, prints the ticket token in the server console and shows the QR on the success page. Use for local testing only. |

### Getting mailer credentials (Brevo example)

1. Create a free account at brevo.com.
2. Go to **SMTP & API → SMTP** and copy the login and generate an SMTP key.
3. Verify your sender email under **Senders**.
4. Put the values in `.env` as `SMTP_USER`, `SMTP_PASS`, `MAIL_FROM`.

## Run locally

```bash
git clone https://github.com/YOUR-USERNAME/event-ticketing.git
cd event-ticketing
npm install
cp .env.example .env     # on Windows: copy .env.example .env
# edit .env: set TICKET_SECRET and ORGANIZER_KEY (and SMTP_* for real email)
npm start
```

Open http://localhost:3000. Three sample events are created on first run (one has only 3 seats so you can test the capacity limit quickly). To reset the data, stop the server and delete `tickets.db`.

## Test the organizer scan workflow locally

Option A: with real email

1. Set the `SMTP_*` variables and `DEV_MODE=false`.
2. Register for an event using your own email.
3. Open the email on your phone.
4. Go to http://localhost:3000/organizer.html, enter your `ORGANIZER_KEY`, allow camera access, and point the laptop webcam at the QR on your phone.

Option B: without email (DEV_MODE)

1. Set `DEV_MODE=true` and restart.
2. Register for an event. The success page shows the QR and its token (also printed in the server console).
3. Open the organizer page, unlock it, then either scan the QR on screen or paste the token into **Manual token**.

Expected results

| Action | Result |
|---|---|
| Scan a valid ticket the first time | Green: **CHECKED-IN** with name and event |
| Scan the same ticket again | Amber: **ALREADY USED** with the first check-in time |
| Paste `abc.fakesignature` | Red: **INVALID TICKET** |
| Change one character of a valid token | Red: **INVALID TICKET** |
| Register for a full event | Registration rejected: "This event is full" |
| Register twice with the same email | Rejected: "already registered" |

Note: browsers only allow camera access on `localhost` or HTTPS.

## API

- `GET /api/events` and `GET /api/events/:id`: events with `registered` and `spotsLeft`.
- `POST /api/register` with `{ eventId, name, email }`: creates the registration and sends the ticket email.
- `POST /api/verify` with `{ token }` and header `x-organizer-key`: returns `CHECKED_IN`, `ALREADY_USED` or `INVALID`.

## Security notes

- Tickets are signed with HMAC-SHA256 and compared in constant time.
- Check-in uses a conditional `UPDATE ... WHERE status='REGISTERED'`, so two simultaneous scans cannot both succeed.
- The verify endpoint requires the organizer key.
- `.env` and the database file are git-ignored.
