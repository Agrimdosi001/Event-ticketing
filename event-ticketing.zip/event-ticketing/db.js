const Database = require('better-sqlite3');
const db = new Database(process.env.DB_FILE || 'tickets.db');

db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  description TEXT,
  venue TEXT,
  event_date TEXT,
  capacity INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS registrations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  event_id INTEGER NOT NULL REFERENCES events(id),
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  ticket_id TEXT UNIQUE NOT NULL,
  status TEXT NOT NULL DEFAULT 'REGISTERED',
  checked_in_at TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(event_id, email)
);
`);

// Seed sample events on first run
if (db.prepare('SELECT COUNT(*) AS c FROM events').get().c === 0) {
  const ins = db.prepare(
    'INSERT INTO events (title, description, venue, event_date, capacity) VALUES (?,?,?,?,?)'
  );
  ins.run('Hack Night 2026', 'Six hours of building, pizza and mentors from the coding club.', 'Lab Block B, Room 204', '2026-11-14 18:00', 50);
  ins.run('Open Mic Evening', 'Music, poetry and stand-up from students. Sign up to perform at the door.', 'Main Auditorium', '2026-11-21 17:30', 3);
  ins.run('Robotics Demo Day', 'Watch club robots compete in a line-following and sumo showdown.', 'Workshop Hall', '2026-12-02 15:00', 120);
}

module.exports = db;
