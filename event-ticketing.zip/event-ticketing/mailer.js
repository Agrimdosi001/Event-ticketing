const nodemailer = require('nodemailer');
const QRCode = require('qrcode');

const devMode = String(process.env.DEV_MODE).toLowerCase() === 'true';

let transporter = null;
function getTransporter() {
  if (!transporter) {
    transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: Number(process.env.SMTP_PORT || 587),
      secure: Number(process.env.SMTP_PORT) === 465,
      auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS },
    });
  }
  return transporter;
}

const esc = (s) =>
  String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

function buildHtml({ name, event }) {
  return `<!doctype html>
<html><body style="margin:0;padding:24px;background:#eef1f4;font-family:Arial,Helvetica,sans-serif;color:#101820">
  <table role="presentation" width="100%" style="max-width:480px;margin:0 auto;background:#ffffff;border-radius:10px;overflow:hidden">
    <tr><td style="background:#2f5bff;color:#fff;padding:20px 24px">
      <div style="font-size:13px;opacity:.85">Your ticket</div>
      <div style="font-size:22px;font-weight:bold;margin-top:4px">${esc(event.title)}</div>
    </td></tr>
    <tr><td style="padding:24px">
      <p style="margin:0 0 16px">Hi ${esc(name)}, you're registered.</p>
      <p style="margin:0 0 4px"><b>When:</b> ${esc(event.event_date)}</p>
      <p style="margin:0 0 20px"><b>Where:</b> ${esc(event.venue)}</p>
      <div style="text-align:center;padding:16px;border:2px dashed #c3cad3;border-radius:8px">
        <img src="cid:ticketqr" width="240" height="240" alt="Ticket QR code" style="display:block;margin:0 auto">
        <p style="margin:12px 0 0;font-size:13px;color:#566170">Show this code at the entrance. It works once.</p>
      </div>
      <p style="margin:20px 0 0;font-size:12px;color:#8a94a1">Don't share this email. Anyone with the QR code can use your ticket.</p>
    </td></tr>
  </table>
</body></html>`;
}

async function sendTicket({ to, name, event, token }) {
  if (devMode) {
    console.log(`\n[DEV_MODE] Ticket for ${to}\n  token: ${token}\n`);
    return { dev: true };
  }
  const qrBuffer = await QRCode.toBuffer(token, { width: 400, margin: 2, errorCorrectionLevel: 'M' });
  await getTransporter().sendMail({
    from: process.env.MAIL_FROM,
    to,
    subject: `Your ticket for ${event.title}`,
    text: `Hi ${name}, you're registered for ${event.title} (${event.event_date}, ${event.venue}). Your QR ticket is attached to this email.`,
    html: buildHtml({ name, event }),
    attachments: [{ filename: 'ticket.png', content: qrBuffer, cid: 'ticketqr' }],
  });
  return { dev: false };
}

module.exports = { sendTicket, devMode };
