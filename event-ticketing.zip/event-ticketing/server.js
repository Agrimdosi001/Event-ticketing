require('dotenv').config();
const crypto = require('crypto');
const express = require('express');
const QRCode = require('qrcode');
const db = require('./db');
const { createToken, verifyToken } = require('./tokens');
const { sendTicket, devMode } = require('./mailer');

const app = express();
app.use(express.json({ limit: '10kb' }));
app.use(express.static('public'));

// ---------- Events ----------
const eventsWithCounts = db.prepare(`
  SELECT e.*, COUNT(r.id) AS registered
  FROM events e LEFT JOIN registrations r ON r.event_id = e.id
  GROUP BY e.id ORDER BY e.event_date
`);

function shape(e) {
  return { ...e, spotsLeft: Math.max(e.capacity - e.registered, 0) };
}

app.get('/api/events', (req, res) => {
  res.json(eventsWithCounts.all().map(shape));
});

app.get('/api/events/:id', (req, res) => {
  const e = eventsWithCounts.all().find((x) => x.id === Number(req.params.id));
  if (!e) return res.status(404).json({ error: 'Event not found' });
  res.json(shape(e));
});

// ---------- Registration ----------
const registerTx = db.transaction((eventId, name, email) => {
  const event = db.prepare('SELECT * FROM events WHERE id = ?').get(eventId);
  if (!event) throw { status: 404, message: 'Event not found.' };

  const { c } = db.prepare('SELECT COUNT(*) AS c FROM registrations WHERE event_id = ?').get(eventId);
  if (c >= event.capacity) throw { status: 409, message: 'This event is full. Registration is closed.' };

  const ticketId = crypto.randomUUID();
  try {
    db.prepare('INSERT INTO registrations (event_id, name, email, ticket_id) VALUES (?,?,?,?)')
      .run(eventId, name, email, ticketId);
  } catch (err) {
    if (String(err.code).startsWith('SQLITE_CONSTRAINT')) {
      throw { status: 409, message: 'This email is already registered for the event.' };
    }
    throw err;
  }
  return { ticketId, event };
});

app.post('/api/register', async (req, res) => {
  const eventId = Number(req.body.eventId);
  const name = String(req.body.name || '').trim();
  const email = String(req.body.email || '').trim().toLowerCase();

  if (!Number.isInteger(eventId)) return res.status(400).json({ error: 'Choose an event.' });
  if (name.length < 2 || name.length > 80) return res.status(400).json({ error: 'Enter your full name.' });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 120)
    return res.status(400).json({ error: 'Enter a valid email address.' });

  let result;
  try {
    result = registerTx(eventId, name, email);
  } catch (err) {
    if (err.status) return res.status(err.status).json({ error: err.message });
    console.error(err);
    return res.status(500).json({ error: 'Something went wrong. Try again.' });
  }

  const token = createToken(result.ticketId);
  try {
    await sendTicket({ to: email, name, event: result.event, token });
  } catch (err) {
    // Free the seat if the ticket email could not be sent
    db.prepare('DELETE FROM registrations WHERE ticket_id = ?').run(result.ticketId);
    console.error('Email failed:', err.message);
    return res.status(502).json({ error: 'We could not send your ticket email. Check the address and try again.' });
  }

  const body = { ok: true, eventTitle: result.event.title, email };
  if (devMode) body.devToken = token; // local testing only
  res.json(body);
});

// DEV_MODE only: render a QR for a token so the flow can be tested without email
app.get('/api/dev/qr', async (req, res) => {
  if (!devMode) return res.status(404).end();
  const png = await QRCode.toBuffer(String(req.query.token || ''), { width: 300, margin: 2 });
  res.type('png').send(png);
});

// ---------- Organizer verification ----------
function requireOrganizer(req, res, next) {
  const key = String(req.get('x-organizer-key') || '');
  const real = String(process.env.ORGANIZER_KEY || '');
  const a = Buffer.from(key), b = Buffer.from(real);
  if (!real || a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
    return res.status(401).json({ error: 'Wrong organizer key.' });
  }
  next();
}

app.post('/api/verify', requireOrganizer, (req, res) => {
  const ticketId = verifyToken(req.body.token);
  if (!ticketId) return res.json({ result: 'INVALID' });

  const reg = db.prepare(`
    SELECT r.name, r.email, r.status, r.checked_in_at, e.title AS event
    FROM registrations r JOIN events e ON e.id = r.event_id
    WHERE r.ticket_id = ?`).get(ticketId);
  if (!reg) return res.json({ result: 'INVALID' });

  // Atomic: only the first scan can flip REGISTERED -> CHECKED_IN
  const now = new Date().toISOString();
  const upd = db.prepare(
    "UPDATE registrations SET status='CHECKED_IN', checked_in_at=? WHERE ticket_id=? AND status='REGISTERED'"
  ).run(now, ticketId);

  if (upd.changes === 1) {
    return res.json({ result: 'CHECKED_IN', name: reg.name, email: reg.email, event: reg.event, checkedInAt: now });
  }
  const original = db.prepare('SELECT checked_in_at FROM registrations WHERE ticket_id=?').get(ticketId);
  res.json({ result: 'ALREADY_USED', name: reg.name, email: reg.email, event: reg.event, checkedInAt: original.checked_in_at });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Event ticketing running at http://localhost:${PORT}`);
  if (devMode) console.log('DEV_MODE is on: emails are NOT sent, tokens print here.');
});
