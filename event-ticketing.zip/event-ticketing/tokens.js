const crypto = require('crypto');

function secret() {
  const s = process.env.TICKET_SECRET;
  if (!s || s.length < 16) {
    throw new Error('TICKET_SECRET is missing or too short. Set it in .env');
  }
  return s;
}

function sign(ticketId) {
  return crypto.createHmac('sha256', secret()).update(ticketId).digest('base64url');
}

// Token format: <ticketId>.<signature>
function createToken(ticketId) {
  return `${ticketId}.${sign(ticketId)}`;
}

// Returns the ticketId if the signature is valid, otherwise null
function verifyToken(token) {
  if (typeof token !== 'string' || token.length > 200) return null;
  const parts = token.trim().split('.');
  if (parts.length !== 2 || !parts[0] || !parts[1]) return null;
  const [ticketId, sig] = parts;
  const expected = Buffer.from(sign(ticketId));
  const given = Buffer.from(sig);
  if (given.length !== expected.length) return null;
  return crypto.timingSafeEqual(given, expected) ? ticketId : null;
}

module.exports = { createToken, verifyToken };
